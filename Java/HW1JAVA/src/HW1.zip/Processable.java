import java.util.ArrayList;

public interface Processable
{
    void process(ArrayList<Float> audio);
}
